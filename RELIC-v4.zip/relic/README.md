# RELIC – Retro Gaming Emulator (Android)

*Seu passado gamer, em uma nova dimensão.*

## Status: etapa 4 (backup, slots, filtros, som, controles)

Etapa 1 (interface e biblioteca) continua valendo. Novidades da etapa 2:

- **Importar pasta**: varre a pasta e as subpastas e adiciona tudo que reconhecer.
  - O console vem da extensão quando ela é inequívoca (.nes, .sfc, .gba, .md...).
  - Para formatos compartilhados (.zip, .7z, .iso, .cue, .bin, .chd) o console vem do nome de alguma
    pasta: SNES, GBA, Mega Drive, PSX, MAME, FBNeo, Neo Geo etc. Sem pista, o arquivo é ignorado e contado.
  - Em consoles de disco (PS1, PS2, Sega CD), arquivos .bin ao lado do .cue não viram jogos separados.
  - A pasta de origem aparece no cartão do jogo, e a Biblioteca agrupa por console.
- **Capas automáticas**: baixadas do servidor de miniaturas do libretro, pelo nome do arquivo
  (ex.: `Super Mario World (USA).sfc`). Funciona melhor com nomes no padrão No-Intro.
- **Descrições automáticas**: resumo da Wikipédia (pt, depois en), aceito só quando o título bate
  e a primeira frase fala de jogo. A fonte aparece no fim do texto. Dá para editar à mão.
- **Buscar capas**: tenta de novo para quem ficou sem capa ou descrição.
- Interruptor em Configurações para desligar a busca na internet. Só o nome do jogo é enviado.
- O banco migrou para a versão 2 (coluna `folder`) sem perder dados da etapa 1.

Limites conhecidos (honestos):
- Arcade (MAME, FBNeo, CPS, Neo Geo) usa nomes de romset (`sf2.zip`), que não casam com as capas.
  Esses jogos ficam com capa genérica. Descrição pode falhar pelo mesmo motivo.
- Ano, gênero e desenvolvedora ainda são preenchidos à mão (botão de editar). A leitura dos
  bancos de dados do libretro (por CRC) ficou para uma próxima rodada.
- Os nomes das pastas de capas por console foram escritos de memória e não foram testados
  contra o servidor. Se algum console nunca achar capa, é o primeiro lugar a conferir
  (`MetadataRepository.thumbFolder`).

Ainda NÃO existe:
- Etapa 3: núcleos libretro. O botão "Iniciar" só informa que o núcleo não está integrado.
- Etapa 4: controles, save states, filtros, áudio, backup.

### Etapa 3: emulação de verdade (NES, Game Boy, Game Boy Color)
- Motor: biblioteca **LibretroDroid** (roda núcleos libretro no Android). Núcleos: FCEUmm (NES) e Gambatte (GB/GBC).
- Ao tocar em **Iniciar** pela primeira vez, o app pede para baixar o núcleo do servidor oficial do libretro.
  Depois disso o jogo abre direto. ROMs dentro de .zip são aceitas (usa o primeiro arquivo do pacote).
- Controles na tela (direcional, A, B, Select, Start) e gamepad físico por Bluetooth/USB (botões e direcional).
- Salvar estado e carregar estado (1 slot por jogo), e o salvamento normal do jogo (bateria) é gravado ao sair.
- Jogar registra o jogo no Histórico.
- Os outros consoles continuam sem núcleo e o app avisa isso ao tocar em Iniciar.

**NÃO verificado (escrito sem compilar nem rodar):**
1. A versão da LibretroDroid em `app/build.gradle.kts` está como `master-SNAPSHOT` (a página do projeto não mostrou a última versão).
   Troque pela versão numerada em https://github.com/Swordfish90/LibretroDroid/releases se o Gradle não resolver.
2. Os nomes da API (`GLRetroView`, `GLRetroViewData`, `sendKeyEvent`, `serializeState`, `serializeSRAM`...) estão em
   `EmulatorActivity.kt` e vieram de memória. Se o build acusar erro, é só nesse arquivo.
3. O endereço de download dos núcleos fica em `CoreManager.kt` (padrão do atualizador do RetroArch). Se der HTTP 404, ajuste lá.
4. O mapeamento A/B na tela pode estar trocado em relação ao jogo. Teste e me avise.
5. Ainda não há: direcional analógico/hat, filtros, mapeamento de botões, vários slots de estado (etapa 4).
6. Para publicar na Play Store, núcleos baixados em tempo de execução provavelmente não serão aceitos; teria que embuti-los no APK.

### Etapa 4: configurações e salvamentos
- **3 slots de estado salvo** por jogo (chips "Slot 1/2/3" no topo da tela de jogo).
- **Filtros de vídeo** (Sem filtro, CRT, LCD) e **som ligado/desligado** em Configurações. Valem no próximo jogo aberto.
- **Trocar A e B** (tela e gamepad) e **direcional analógico/hat** de gamepads funcionando como direcional.
- **Backup** em .zip (biblioteca, saves, estados e capas) com **restaurar**. Restaurar fecha o app para recarregar o banco.
  ROMs e núcleos não entram no backup: depois de reinstalar ou trocar de aparelho, importe os jogos de novo.
- **Armazenamento**: tamanho de núcleos, capas e saves, e botão para apagar os núcleos baixados.

Não verificado nesta etapa (mesma ressalva da etapa 3): `ShaderConfig.CRT/LCD/Default` e `audioEnabled` da LibretroDroid,
ambos só em `EmulatorActivity.kt`. Ainda não existe: mapeamento livre de cada botão, resolução ajustável, núcleos dos demais consoles,
capas de arcade, ano/gênero/desenvolvedora automáticos.

## Como abrir
1. Android Studio (Koala ou mais novo), JDK 17.
2. File > Open > pasta `relic`. O Gradle baixa as dependências.
3. Rode em um aparelho ou emulador com Android 8.0+.

Este código foi escrito sem compilar nem testar (sem Android SDK nem acesso aos servidores no
ambiente de criação). Se o Gradle reclamar de alguma versão, ajuste em `build.gradle.kts` e
`app/build.gradle.kts`.

## Gerar o APK para testar
**Opção A, Android Studio:** abra a pasta, espere o Gradle sincronizar e use *Build > Build APK(s)*.
O arquivo sai em `app/build/outputs/apk/debug/app-debug.apk`.

**Opção B, sem instalar nada (GitHub):** crie um repositório, envie o conteúdo desta pasta e abra
*Actions > Build APK > Run workflow*. Ao terminar, baixe `RELIC-debug-apk` e instale no celular
(permita "instalar apps desconhecidos"). O workflow está em `.github/workflows/build-apk.yml`.

**Linha de comando:** `./gradlew assembleDebug` (precisa do Android SDK instalado).
