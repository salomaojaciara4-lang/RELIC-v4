package com.relic.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.lifecycleScope
import com.relic.app.data.Game
import com.relic.app.data.ConsoleType
import com.relic.app.data.CoreManager
import com.relic.app.ui.Neon
import com.relic.app.ui.RelicTheme
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.ShaderConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipInputStream

/**
 * Tela de jogo. TODA a integração com a biblioteca LibretroDroid fica neste arquivo
 * (GLRetroView, GLRetroViewData, sendKeyEvent, serializeState, unserializeState,
 * serializeSRAM, ShaderConfig.CRT/LCD/Default, audioEnabled). Os nomes vieram da documentação do projeto, de memória, e não foram
 * compilados: se o build acusar erro nessas chamadas, o ajuste é só aqui.
 */
class EmulatorActivity : ComponentActivity() {

    private var retroView by mutableStateOf<GLRetroView?>(null)
    private var gameId = -1L
    private var slot by mutableIntStateOf(1)

    // Preferências escolhidas em Configurações (lidas ao abrir o jogo)
    private var filter = "none"
    private var sound = true
    private var swapAB = false

    private fun stateFile(slot: Int) =
        File(File(filesDir, "states").apply { mkdirs() }, "$gameId-$slot.state")
    private val sramFile get() = File(File(filesDir, "saves").apply { mkdirs() }, "$gameId.srm")

    /** Direcional virtual para analógico e "hat" de gamepads: último estado enviado em cada eixo. */
    private var padX = 0
    private var padY = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val prefs = getSharedPreferences("relic_prefs", Context.MODE_PRIVATE)
        filter = prefs.getString("filter", "none") ?: "none"
        sound = prefs.getBoolean("sound", true)
        swapAB = prefs.getBoolean("swapAB", false)

        gameId = intent.getLongExtra(EXTRA_ID, -1)
        val uri = Uri.parse(intent.getStringExtra(EXTRA_URI))
        val fileName = intent.getStringExtra(EXTRA_FILE).orEmpty()
        val core = ConsoleType.fromName(intent.getStringExtra(EXTRA_CONSOLE).orEmpty())?.core

        setContent { RelicTheme(0.8f) { GameScreen() } }

        if (core == null) {
            fail("Este console ainda não tem núcleo integrado.")
            return
        }
        lifecycleScope.launch { start(uri, fileName, core) }
    }

    private suspend fun start(uri: Uri, fileName: String, core: String) {
        try {
            val rom = withContext(Dispatchers.IO) { readRom(uri, fileName) }
            val sram = withContext(Dispatchers.IO) { sramFile.takeIf { it.exists() }?.readBytes() }
            val data = GLRetroViewData(this).apply {
                coreFilePath = CoreManager.coreFile(this@EmulatorActivity, core).absolutePath
                gameFileBytes = rom
                systemDirectory = File(filesDir, "system").apply { mkdirs() }.absolutePath
                savesDirectory = File(filesDir, "saves").apply { mkdirs() }.absolutePath
                saveRAMState = sram
                // Filtro de vídeo. Nomes de ShaderConfig não verificados (ver comentário da classe).
                shader = when (filter) {
                    "crt" -> ShaderConfig.CRT
                    "lcd" -> ShaderConfig.LCD
                    else -> ShaderConfig.Default
                }
            }
            val view = GLRetroView(this, data)
            view.audioEnabled = sound
            lifecycle.addObserver(view)
            retroView = view
        } catch (t: Throwable) { // inclui UnsatisfiedLinkError, que não é Exception
            fail("Não foi possível iniciar o jogo: ${t.message ?: t.javaClass.simpleName}")
        }
    }

    /** Lê a ROM inteira. Se vier dentro de um .zip, usa o primeiro arquivo do pacote. */
    private fun readRom(uri: Uri, fileName: String): ByteArray {
        val input = contentResolver.openInputStream(uri) ?: error("Não consegui abrir o arquivo.")
        return input.use {
            if (fileName.endsWith(".zip", ignoreCase = true)) {
                ZipInputStream(it).use { zip ->
                    var e = zip.nextEntry
                    while (e != null && e.isDirectory) e = zip.nextEntry
                    if (e == null) error("O .zip está vazio.")
                    zip.readBytes()
                }
            } else it.readBytes()
        }
    }

    private fun fail(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        finish()
    }

    // ---------- save state e SRAM ----------

    private fun saveState() {
        val view = retroView ?: return
        runCatching { stateFile(slot).writeBytes(view.serializeState()) }
            .onSuccess { toast("Estado salvo no slot $slot.") }
            .onFailure { toast("Não foi possível salvar o estado.") }
    }

    private fun loadState() {
        val view = retroView ?: return
        if (!stateFile(slot).exists()) return toast("O slot $slot está vazio.")
        runCatching { view.unserializeState(stateFile(slot).readBytes()) }
            .onSuccess { toast("Estado do slot $slot carregado.") }
            .onFailure { toast("Não foi possível carregar o estado.") }
    }

    /** Salvamento normal do jogo (bateria do cartucho), gravado ao sair da tela. */
    private fun saveSram() {
        val view = retroView ?: return
        runCatching { sramFile.writeBytes(view.serializeSRAM()) }
    }

    override fun onStop() {
        saveSram()
        super.onStop()
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    // ---------- controles físicos ----------

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val view = retroView
        val fromPad = event.source and InputDevice.SOURCE_GAMEPAD == InputDevice.SOURCE_GAMEPAD ||
            event.source and InputDevice.SOURCE_DPAD == InputDevice.SOURCE_DPAD
        if (view != null && fromPad && event.keyCode != KeyEvent.KEYCODE_BACK) {
            view.sendKeyEvent(event.action, swapKey(event.keyCode))
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    /** Aplica "Trocar A e B" às teclas A/B (tela e gamepad). */
    private fun swapKey(keyCode: Int): Int = if (!swapAB) keyCode else when (keyCode) {
        KeyEvent.KEYCODE_BUTTON_A -> KeyEvent.KEYCODE_BUTTON_B
        KeyEvent.KEYCODE_BUTTON_B -> KeyEvent.KEYCODE_BUTTON_A
        else -> keyCode
    }

    /** Hat e analógico esquerdo do gamepad viram o direcional (com zona morta de 50%). */
    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        val isStick = event.source and InputDevice.SOURCE_JOYSTICK == InputDevice.SOURCE_JOYSTICK
        if (retroView == null || !isStick || event.action != MotionEvent.ACTION_MOVE) {
            return super.onGenericMotionEvent(event)
        }
        fun axis(hat: Int, stick: Int): Float =
            event.getAxisValue(hat).let { if (it != 0f) it else event.getAxisValue(stick) }
        val x = axis(MotionEvent.AXIS_HAT_X, MotionEvent.AXIS_X)
        val y = axis(MotionEvent.AXIS_HAT_Y, MotionEvent.AXIS_Y)
        val nx = if (x < -0.5f) -1 else if (x > 0.5f) 1 else 0
        val ny = if (y < -0.5f) -1 else if (y > 0.5f) 1 else 0
        if (nx != padX) {
            if (padX != 0) press(KeyEvent.ACTION_UP, if (padX < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT)
            if (nx != 0) press(KeyEvent.ACTION_DOWN, if (nx < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT)
            padX = nx
        }
        if (ny != padY) {
            if (padY != 0) press(KeyEvent.ACTION_UP, if (padY < 0) KeyEvent.KEYCODE_DPAD_UP else KeyEvent.KEYCODE_DPAD_DOWN)
            if (ny != 0) press(KeyEvent.ACTION_DOWN, if (ny < 0) KeyEvent.KEYCODE_DPAD_UP else KeyEvent.KEYCODE_DPAD_DOWN)
            padY = ny
        }
        return true
    }

    // ---------- interface ----------

    private fun press(action: Int, keyCode: Int) {
        retroView?.sendKeyEvent(action, swapKey(keyCode))
    }

    @Composable
    private fun GameScreen() {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val view = retroView
            if (view == null) {
                CircularProgressIndicator(Modifier.align(Alignment.Center), color = Neon.Purple)
            } else {
                AndroidView(factory = { view }, modifier = Modifier.fillMaxSize())
            }

            Row(
                Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TopButton("Sair") { finish() }
                (1..3).forEach { n ->
                    FilterChip(
                        selected = slot == n, onClick = { slot = n },
                        label = { Text("Slot $n") },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = Color.Black.copy(alpha = 0.4f),
                            labelColor = Color.White,
                            selectedContainerColor = Neon.Purple,
                            selectedLabelColor = Color.White
                        )
                    )
                }
                TopButton("Salvar") { saveState() }
                TopButton("Carregar") { loadState() }
            }

            // D-pad (esquerda)
            Box(Modifier.align(Alignment.BottomStart).navigationBarsPadding().padding(24.dp).size(168.dp)) {
                PadButton("▲", KeyEvent.KEYCODE_DPAD_UP, Modifier.align(Alignment.TopCenter))
                PadButton("▼", KeyEvent.KEYCODE_DPAD_DOWN, Modifier.align(Alignment.BottomCenter))
                PadButton("◀", KeyEvent.KEYCODE_DPAD_LEFT, Modifier.align(Alignment.CenterStart))
                PadButton("▶", KeyEvent.KEYCODE_DPAD_RIGHT, Modifier.align(Alignment.CenterEnd))
            }

            // Botões de ação (direita). A posição segue o aparelho: "B" à esquerda, "A" à direita.
            Row(
                Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(24.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                PadButton("B", KeyEvent.KEYCODE_BUTTON_A, Modifier.padding(bottom = 0.dp), 64.dp)
                PadButton("A", KeyEvent.KEYCODE_BUTTON_B, Modifier.padding(bottom = 40.dp), 64.dp)
            }

            // Select e Start (centro)
            Row(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                PillButton("SELECT", KeyEvent.KEYCODE_BUTTON_SELECT)
                PillButton("START", KeyEvent.KEYCODE_BUTTON_START)
            }
        }
    }

    @Composable
    private fun TopButton(label: String, onClick: () -> Unit) {
        OutlinedButton(onClick = onClick, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) {
            Text(label)
        }
    }

    @Composable
    private fun PadButton(label: String, keyCode: Int, modifier: Modifier, size: Dp = 56.dp) {
        Box(
            modifier.size(size).clip(CircleShape)
                .background(Neon.Purple.copy(alpha = 0.30f))
                .border(1.dp, Neon.Purple, CircleShape)
                .pointerInput(keyCode) {
                    detectTapGestures(onPress = {
                        press(KeyEvent.ACTION_DOWN, keyCode)
                        tryAwaitRelease()
                        press(KeyEvent.ACTION_UP, keyCode)
                    })
                },
            contentAlignment = Alignment.Center
        ) { Text(label, color = Color.White) }
    }

    @Composable
    private fun PillButton(label: String, keyCode: Int) {
        Box(
            Modifier.height(36.dp).width(88.dp).clip(RoundedCornerShape(18.dp))
                .background(Neon.Purple.copy(alpha = 0.30f))
                .border(1.dp, Neon.Purple, RoundedCornerShape(18.dp))
                .pointerInput(keyCode) {
                    detectTapGestures(onPress = {
                        press(KeyEvent.ACTION_DOWN, keyCode)
                        tryAwaitRelease()
                        press(KeyEvent.ACTION_UP, keyCode)
                    })
                },
            contentAlignment = Alignment.Center
        ) { Text(label, color = Color.White, style = MaterialTheme.typography.labelSmall) }
    }

    companion object {
        private const val EXTRA_ID = "id"
        private const val EXTRA_URI = "uri"
        private const val EXTRA_FILE = "file"
        private const val EXTRA_CONSOLE = "console"

        fun intent(context: Context, game: Game) = Intent(context, EmulatorActivity::class.java)
            .putExtra(EXTRA_ID, game.id)
            .putExtra(EXTRA_URI, game.uri)
            .putExtra(EXTRA_FILE, game.fileName)
            .putExtra(EXTRA_CONSOLE, game.console)
    }
}
