package com.relic.app.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Neon {
    val Bg = Color(0xFF0A0612)
    val Surface = Color(0xFF150C24)
    val SurfaceHigh = Color(0xFF1E1233)
    val Purple = Color(0xFFB026FF)
    val Violet = Color(0xFF7B2FFF)
    val Pink = Color(0xFFFF4DDB)
    val Text = Color(0xFFF1E9FF)
    val Muted = Color(0xFF9B8BB8)
    val Gradient = Brush.linearGradient(listOf(Violet, Purple, Pink))
}

/** Intensidade do neon (0..1), controlada em Configurações. */
val LocalNeon = compositionLocalOf { 0.8f }

/** Borda e brilho roxos; o brilho escala com a intensidade escolhida. */
fun Modifier.neonGlow(radius: Dp = 12.dp, intensity: Float, corner: Dp = 16.dp): Modifier {
    val shape = RoundedCornerShape(corner)
    val glow = Neon.Purple.copy(alpha = 0.25f + 0.75f * intensity)
    return this
        .shadow(radius * intensity, shape, ambientColor = glow, spotColor = glow)
        .border(1.dp, Neon.Purple.copy(alpha = 0.35f + 0.65f * intensity), shape)
}

private val scheme = darkColorScheme(
    primary = Neon.Purple,
    onPrimary = Color.White,
    secondary = Neon.Violet,
    tertiary = Neon.Pink,
    background = Neon.Bg,
    onBackground = Neon.Text,
    surface = Neon.Surface,
    onSurface = Neon.Text,
    surfaceVariant = Neon.SurfaceHigh,
    onSurfaceVariant = Neon.Muted,
    outline = Neon.Violet
)

private val type = Typography(
    headlineMedium = TextStyle(fontWeight = FontWeight.Black, fontSize = 28.sp, letterSpacing = 4.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 20.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
    bodyMedium = TextStyle(fontSize = 14.sp),
    labelSmall = TextStyle(fontSize = 11.sp, letterSpacing = 0.5.sp)
)

@Composable
fun RelicTheme(neon: Float, content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalNeon provides neon) {
        MaterialTheme(colorScheme = scheme, typography = type, content = content)
    }
}
