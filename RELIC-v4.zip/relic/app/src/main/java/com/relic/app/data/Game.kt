package com.relic.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "games")
data class Game(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val uri: String,              // URI persistente do Storage Access Framework
    val fileName: String,
    val console: String,          // nome do enum ConsoleType
    val favorite: Boolean = false,
    val addedAt: Long = System.currentTimeMillis(),
    val lastPlayed: Long? = null,
    val year: Int? = null,
    val genre: String? = null,
    val developer: String? = null,
    val description: String? = null,
    val coverUri: String? = null, // caminho local da capa baixada (filesDir/covers)
    val folder: String? = null    // pasta de origem (importação por pasta)
)

@Dao
interface GameDao {
    @Query("SELECT * FROM games ORDER BY title COLLATE NOCASE")
    fun observeAll(): Flow<List<Game>>

    @Query("SELECT * FROM games ORDER BY addedAt DESC LIMIT 12")
    fun observeRecent(): Flow<List<Game>>

    @Query("SELECT * FROM games WHERE favorite = 1 ORDER BY title COLLATE NOCASE")
    fun observeFavorites(): Flow<List<Game>>

    @Query("SELECT * FROM games WHERE lastPlayed IS NOT NULL ORDER BY lastPlayed DESC")
    fun observeHistory(): Flow<List<Game>>

    @Query("SELECT * FROM games WHERE coverUri IS NULL OR description IS NULL")
    suspend fun missingMetadata(): List<Game>

    @Query("SELECT COUNT(*) FROM games WHERE uri = :uri")
    suspend fun countByUri(uri: String): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(game: Game): Long

    @Query("UPDATE games SET favorite = :fav WHERE id = :id")
    suspend fun setFavorite(id: Long, fav: Boolean)

    @Query("UPDATE games SET coverUri = :path WHERE id = :id")
    suspend fun setCover(id: Long, path: String)

    @Query("UPDATE games SET description = :text WHERE id = :id AND description IS NULL")
    suspend fun setDescription(id: Long, text: String)

    @Query("UPDATE games SET title = :title, year = :year, genre = :genre, developer = :dev, description = :desc WHERE id = :id")
    suspend fun updateInfo(id: Long, title: String, year: Int?, genre: String?, dev: String?, desc: String?)

    @Query("UPDATE games SET lastPlayed = :time WHERE id = :id")
    suspend fun markPlayed(id: Long, time: Long)

    @Query("DELETE FROM games WHERE id = :id")
    suspend fun delete(id: Long)
}

@Database(entities = [Game::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun games(): GameDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE games ADD COLUMN folder TEXT")
            }
        }

        /** Grava no arquivo principal o que ainda está no log (WAL), antes de copiar o banco. */
        fun checkpoint(context: Context) {
            get(context).openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close()
        }

        /** Fecha o banco (usado ao restaurar um backup). */
        fun close() {
            synchronized(this) {
                instance?.close()
                instance = null
            }
        }

        @Volatile private var instance: AppDatabase? = null
        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext, AppDatabase::class.java, "relic.db"
            ).addMigrations(MIGRATION_1_2).build().also { instance = it }
        }
    }
}
