package com.relic.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Busca capas no repositório público de miniaturas do libretro
 * (https://thumbnails.libretro.com). As imagens são nomeadas pelo título
 * completo do jogo, no padrão No-Intro: "Super Mario World (USA)".
 * Por isso a busca funciona melhor quando o NOME DO ARQUIVO segue esse padrão.
 * Jogos de arcade (nomes curtos como "sf2.zip") quase nunca encontram capa.
 */
object CoverFetcher {
    private val systems: Map<ConsoleType, String> = mapOf(
        ConsoleType.NES to "Nintendo - Nintendo Entertainment System",
        ConsoleType.SNES to "Nintendo - Super Nintendo Entertainment System",
        ConsoleType.N64 to "Nintendo - Nintendo 64",
        ConsoleType.GB to "Nintendo - Game Boy",
        ConsoleType.GBC to "Nintendo - Game Boy Color",
        ConsoleType.GBA to "Nintendo - Game Boy Advance",
        ConsoleType.NDS to "Nintendo - Nintendo DS",
        ConsoleType.SMS to "Sega - Master System - Mark III",
        ConsoleType.MEGADRIVE to "Sega - Mega Drive - Genesis",
        ConsoleType.SEGACD to "Sega - Mega-CD - Sega CD",
        ConsoleType.S32X to "Sega - 32X",
        ConsoleType.GG to "Sega - Game Gear",
        ConsoleType.PS1 to "Sony - PlayStation",
        ConsoleType.PS2 to "Sony - PlayStation 2",
        ConsoleType.PSP to "Sony - PlayStation Portable",
        ConsoleType.MAME to "MAME",
        ConsoleType.FBNEO to "FBNeo - Arcade Games",
        ConsoleType.CPS1 to "Capcom - CP System I",
        ConsoleType.CPS2 to "Capcom - CP System II",
        ConsoleType.CPS3 to "Capcom - CP System III",
        ConsoleType.NEOGEO to "SNK - Neo Geo"
    )

    private val regions = listOf("USA", "Europe", "Japan", "World")

    fun coversDir(context: Context) = File(context.filesDir, "covers").apply { mkdirs() }

    /** Retorna o arquivo da capa baixada, ou null se não encontrou / sem internet. */
    suspend fun fetch(context: Context, game: Game): File? = withContext(Dispatchers.IO) {
        val console = ConsoleType.fromName(game.console) ?: return@withContext null
        val system = systems[console] ?: return@withContext null
        val base = game.fileName.substringBeforeLast('.')
            .replace(Regex("[&*/:`<>?\\\\|]"), "_")
        val candidates = buildList {
            add(base)
            if ('(' !in base) regions.forEach { add("$base ($it)") }
        }
        val out = File(coversDir(context), "${game.id}.png")
        for (name in candidates) {
            val url = "https://thumbnails.libretro.com/${enc(system)}/Named_Boxarts/${enc(name)}.png"
            if (download(url, out)) return@withContext out
        }
        null
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    private fun download(url: String, out: File): Boolean = try {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8_000
            readTimeout = 12_000
        }
        if (conn.responseCode != 200) {
            conn.disconnect(); false
        } else {
            val tmp = File(out.parentFile, out.name + ".tmp")
            conn.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            conn.disconnect()
            tmp.renameTo(out)
        }
    } catch (e: Exception) {
        false
    }
}
