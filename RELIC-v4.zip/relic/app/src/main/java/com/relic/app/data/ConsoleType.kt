package com.relic.app.data

/**
 * Cada console é uma entrada independente. Na etapa 3, cada um receberá
 * o nome do núcleo libretro correspondente em [core].
 */
enum class ConsoleType(
    val label: String,
    val brand: String,
    val extensions: Set<String>,
    val core: String? = null // preenchido na etapa 3 (integração dos núcleos)
) {
    NES("NES", "Nintendo", setOf("nes"), "fceumm"),
    SNES("SNES", "Nintendo", setOf("sfc", "smc")),
    N64("Nintendo 64", "Nintendo", setOf("n64", "z64", "v64")),
    GB("Game Boy", "Nintendo", setOf("gb"), "gambatte"),
    GBC("Game Boy Color", "Nintendo", setOf("gbc"), "gambatte"),
    GBA("Game Boy Advance", "Nintendo", setOf("gba")),
    NDS("Nintendo DS", "Nintendo", setOf("nds")),

    SMS("Master System", "Sega", setOf("sms")),
    MEGADRIVE("Mega Drive", "Sega", setOf("md", "gen", "smd")),
    SEGACD("Sega CD", "Sega", emptySet()),
    S32X("Sega 32X", "Sega", setOf("32x")),
    GG("Game Gear", "Sega", setOf("gg")),

    PS1("PlayStation 1", "Sony", setOf("pbp")),
    PS2("PlayStation 2", "Sony", emptySet()),
    PSP("PSP", "Sony", setOf("cso")),

    MAME("MAME", "Arcade", emptySet()),
    FBNEO("FinalBurn Neo", "Arcade", emptySet()),
    CPS1("CPS1", "Arcade", emptySet()),
    CPS2("CPS2", "Arcade", emptySet()),
    CPS3("CPS3", "Arcade", emptySet()),
    NEOGEO("Neo Geo", "Arcade", emptySet());

    companion object {
        private val byExtension: Map<String, ConsoleType> =
            entries.flatMap { c -> c.extensions.map { it to c } }.toMap()

        /** Console detectado só quando a extensão é inequívoca; senão null (usuário escolhe). */
        fun detect(fileName: String): ConsoleType? =
            byExtension[fileName.substringAfterLast('.', "").lowercase()]

        fun fromName(name: String): ConsoleType? = entries.firstOrNull { it.name == name }

        private val folderAliases: Map<String, ConsoleType> = mapOf(
            "nes" to NES, "famicom" to NES,
            "snes" to SNES, "sfc" to SNES, "superfamicom" to SNES, "supernintendo" to SNES,
            "n64" to N64, "nintendo64" to N64,
            "gb" to GB, "gameboy" to GB,
            "gbc" to GBC, "gameboycolor" to GBC,
            "gba" to GBA, "gameboyadvance" to GBA,
            "nds" to NDS, "ds" to NDS, "nintendods" to NDS,
            "sms" to SMS, "mastersystem" to SMS,
            "megadrive" to MEGADRIVE, "genesis" to MEGADRIVE, "md" to MEGADRIVE,
            "segacd" to SEGACD, "megacd" to SEGACD,
            "32x" to S32X, "sega32x" to S32X,
            "gg" to GG, "gamegear" to GG,
            "ps1" to PS1, "psx" to PS1, "psone" to PS1, "playstation" to PS1,
            "ps2" to PS2, "playstation2" to PS2,
            "psp" to PSP,
            "mame" to MAME,
            "fbneo" to FBNEO, "fba" to FBNEO, "finalburn" to FBNEO, "finalburnneo" to FBNEO,
            "cps1" to CPS1, "cps2" to CPS2, "cps3" to CPS3,
            "neogeo" to NEOGEO
        )

        /** Console sugerido pelo nome da pasta (ex.: "SNES", "Mega Drive", "roms/gba"). */
        fun fromFolderName(name: String): ConsoleType? =
            folderAliases[name.lowercase().filter { it.isLetterOrDigit() }]

        /** Formatos compartilhados entre consoles: só são aceitos quando a pasta indica o console. */
        val ambiguousExtensions = setOf("zip", "7z", "bin", "cue", "chd", "iso")

        /** Consoles de disco: ".bin" ao lado de ".cue" é dado de faixa, não um jogo separado. */
        val discBased = setOf(PS1, PS2, SEGACD)
    }
}
