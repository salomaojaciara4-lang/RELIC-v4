package com.relic.app.data

import android.content.Context
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Baixa núcleos libretro (compilados para Android) do servidor oficial do libretro,
 * só quando o usuário pede. Cada núcleo é guardado em filesDir/cores.
 *
 * ATENÇÃO: o padrão de URL abaixo é o usado pelo atualizador do RetroArch, mas não foi
 * testado a partir do ambiente onde este código foi escrito. Se o download falhar com
 * "HTTP 404", é aqui que se ajusta.
 */
object CoreManager {
    private const val BASE = "https://buildbot.libretro.com/nightly/android/latest"

    val displayNames = mapOf("fceumm" to "FCEUmm (NES)", "gambatte" to "Gambatte (Game Boy / Color)")

    fun coreFile(context: Context, core: String): File =
        File(File(context.filesDir, "cores").apply { mkdirs() }, "${core}_libretro_android.so")

    fun isInstalled(context: Context, core: String) = coreFile(context, core).let { it.exists() && it.length() > 0 }

    private fun abiFolder(): String =
        Build.SUPPORTED_ABIS.firstOrNull { it in setOf("arm64-v8a", "armeabi-v7a", "x86_64", "x86") }
            ?: throw IOException("Arquitetura do aparelho não suportada: ${Build.SUPPORTED_ABIS.joinToString()}")

    /** Baixa e instala o núcleo. Erros voltam como Result.failure com mensagem legível. */
    suspend fun download(context: Context, core: String): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val url = "$BASE/${abiFolder()}/${core}_libretro_android.so.zip"
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000
                readTimeout = 30_000
            }
            try {
                if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode} ao baixar $url")
                val out = coreFile(context, core)
                val tmp = File(out.parentFile, out.name + ".tmp")
                ZipInputStream(conn.inputStream).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null && !entry.name.endsWith(".so")) entry = zip.nextEntry
                    if (entry == null) throw IOException("O arquivo baixado não contém um núcleo (.so).")
                    tmp.outputStream().use { zip.copyTo(it) }
                }
                if (out.exists()) { out.setWritable(true); out.delete() }
                if (!tmp.renameTo(out)) throw IOException("Não consegui salvar o núcleo.")
                // Android 14+ exige que código carregado dinamicamente seja somente leitura.
                out.setReadOnly()
                out
            } finally {
                conn.disconnect()
            }
        }.recoverCatching { e ->
            throw IOException(e.message ?: "Falha ao baixar o núcleo (sem conexão?).", e)
        }
    }
}
