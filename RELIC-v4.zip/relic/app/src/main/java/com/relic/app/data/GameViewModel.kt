package com.relic.app.data

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.IOException

/** Arquivo importado cujo console não pôde ser detectado: o usuário escolhe. */
data class PendingImport(val uri: Uri, val fileName: String)

/** Arquivo achado na varredura de uma pasta. */
private data class Found(val uri: Uri, val name: String, val folder: String, val console: ConsoleType)

class GameViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).games()
    private val prefs = app.getSharedPreferences("relic_prefs", 0)
    private val metadata = MetadataRepository(app)
    private val enrichLock = Mutex()

    val all = dao.observeAll().state()
    val recent = dao.observeRecent().state()
    val favorites = dao.observeFavorites().state()
    val history = dao.observeHistory().state()

    val query = MutableStateFlow("")
    val pending = MutableStateFlow<List<PendingImport>>(emptyList())
    val message = MutableStateFlow<String?>(null)

    /** Progresso da busca de capas/descrições: (feitos, total), ou null quando parado. */
    val enriching = MutableStateFlow<Pair<Int, Int>?>(null)

    /** Intensidade do neon de 0f a 1f, persistida. */
    val neon = MutableStateFlow(prefs.getFloat("neon", 0.8f))

    /** Buscar capas e descrições na internet automaticamente após importar. */
    val online = MutableStateFlow(prefs.getBoolean("online", true))

    /** Filtro de vídeo: "none", "crt" ou "lcd". Vale a partir do próximo jogo aberto. */
    val filter = MutableStateFlow(prefs.getString("filter", "none") ?: "none")
    val sound = MutableStateFlow(prefs.getBoolean("sound", true))
    /** Troca A e B nos controles (tela e gamepad). */
    val swapAB = MutableStateFlow(prefs.getBoolean("swapAB", false))

    /** true depois de restaurar um backup: o app precisa fechar para recarregar o banco. */
    val needsRestart = MutableStateFlow(false)

    fun setFilter(value: String) { filter.value = value; prefs.edit().putString("filter", value).apply() }
    fun setSound(value: Boolean) { sound.value = value; prefs.edit().putBoolean("sound", value).apply() }
    fun setSwapAB(value: Boolean) { swapAB.value = value; prefs.edit().putBoolean("swapAB", value).apply() }

    fun backup(out: Uri) = viewModelScope.launch {
        Backup.export(getApplication(), out)
            .onSuccess { message.value = "Backup criado ($it arquivos)." }
            .onFailure { message.value = "Falha no backup: ${it.message}" }
    }

    fun restore(input: Uri) = viewModelScope.launch {
        Backup.restore(getApplication(), input)
            .onSuccess { needsRestart.value = true }
            .onFailure { message.value = "Falha ao restaurar: ${it.message}" }
    }

    fun setNeon(value: Float) {
        neon.value = value
        prefs.edit().putFloat("neon", value).apply()
    }

    fun setOnline(value: Boolean) {
        online.value = value
        prefs.edit().putBoolean("online", value).apply()
    }

    fun toggleFavorite(game: Game) = viewModelScope.launch { dao.setFavorite(game.id, !game.favorite) }
    fun remove(game: Game) = viewModelScope.launch { dao.delete(game.id) }
    fun markPlayed(game: Game) = viewModelScope.launch { dao.markPlayed(game.id, System.currentTimeMillis()) }

    fun saveInfo(game: Game, title: String, year: Int?, genre: String, dev: String, desc: String) =
        viewModelScope.launch {
            dao.updateInfo(
                game.id, title.ifBlank { game.title }, year,
                genre.ifBlank { null }, dev.ifBlank { null }, desc.ifBlank { null }
            )
        }

    // ---------- Importação de arquivos ----------

    /** Recebe os arquivos escolhidos no seletor do sistema (Storage Access Framework). */
    fun import(uris: List<Uri>) = viewModelScope.launch {
        val resolver = getApplication<Application>().contentResolver
        val inserted = mutableListOf<Game>()
        var duplicated = 0
        val unknown = mutableListOf<PendingImport>()
        for (uri in uris) {
            runCatching {
                resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val name = displayName(uri)
            val console = ConsoleType.detect(name)
            if (console == null) {
                unknown += PendingImport(uri, name)
            } else {
                val game = insert(uri, name, console, folder = null)
                if (game != null) inserted += game else duplicated++
            }
        }
        pending.value = pending.value + unknown
        message.value = summary(inserted.size, duplicated, unknown.size, 0)
        enrich(inserted)
    }

    fun assignConsole(item: PendingImport, console: ConsoleType) = viewModelScope.launch {
        pending.value = pending.value - item
        insert(item.uri, item.fileName, console, folder = null)?.let { enrich(listOf(it)) }
    }

    fun dismissPending(item: PendingImport) {
        pending.value = pending.value - item
    }

    // ---------- Importação de pasta ----------

    /**
     * Varre a pasta (e subpastas). O console vem da extensão quando ela é inequívoca;
     * para formatos compartilhados (.zip, .iso, .cue...) vem do nome de alguma pasta
     * (ex.: "SNES", "Mega Drive", "psx"). Sem pista, o arquivo é ignorado e contado.
     */
    fun importFolder(tree: Uri) = viewModelScope.launch {
        val app = getApplication<Application>()
        runCatching {
            app.contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val root = DocumentFile.fromTreeUri(app, tree)
        if (root == null) {
            message.value = "Não consegui abrir essa pasta."
            return@launch
        }
        var skipped = 0
        val found = withContext(Dispatchers.IO) {
            val out = mutableListOf<Found>()
            fun scan(dir: DocumentFile, path: List<String>) {
                for (child in dir.listFiles()) {
                    val name = child.name ?: continue
                    if (child.isDirectory) {
                        scan(child, path + name)
                        continue
                    }
                    val ext = name.substringAfterLast('.', "").lowercase()
                    val hint = path.asReversed().firstNotNullOfOrNull { ConsoleType.fromFolderName(it) }
                    val console = ConsoleType.detect(name)
                        ?: if (ext in ConsoleType.ambiguousExtensions) {
                            when {
                                hint == null -> { skipped++; null }
                                ext == "bin" && hint in ConsoleType.discBased -> null // faixa do .cue
                                else -> hint
                            }
                        } else null
                    if (console != null) {
                        out += Found(child.uri, name, path.drop(1).joinToString("/").ifEmpty { path.first() }, console)
                    }
                }
            }
            scan(root, listOf(root.name ?: "pasta"))
            out
        }

        val inserted = mutableListOf<Game>()
        var duplicated = 0
        for (f in found) {
            val game = insert(f.uri, f.name, f.console, f.folder)
            if (game != null) inserted += game else duplicated++
        }
        message.value = summary(inserted.size, duplicated, 0, skipped)
            ?: "Nenhum jogo reconhecido nessa pasta."
        enrich(inserted)
    }

    // ---------- Capas e descrições ----------

    /** Tenta de novo para todos os jogos que ainda estão sem capa ou sem descrição. */
    fun enrichMissing() = viewModelScope.launch {
        if (!online.value) {
            message.value = "Ative a busca na internet em Configurações."
            return@launch
        }
        val todo = dao.missingMetadata()
        if (todo.isEmpty()) message.value = "Todos os jogos já têm capa e descrição."
        else enrich(todo, force = true)
    }

    private fun enrich(games: List<Game>, force: Boolean = false) {
        if (games.isEmpty() || (!online.value && !force)) return
        viewModelScope.launch {
            enrichLock.withLock {
                try {
                    for ((i, g) in games.withIndex()) {
                        enriching.value = i to games.size
                        val console = ConsoleType.fromName(g.console) ?: continue
                        if (g.coverUri == null) metadata.cover(g, console)?.let { dao.setCover(g.id, it) }
                        if (g.description == null) metadata.description(g)?.let { dao.setDescription(g.id, it) }
                    }
                } catch (e: IOException) {
                    message.value = "Sem conexão com a internet. Tente de novo em Buscar capas."
                } finally {
                    enriching.value = null
                }
            }
        }
    }

    // ---------- util ----------

    private suspend fun insert(uri: Uri, name: String, console: ConsoleType, folder: String?): Game? {
        if (dao.countByUri(uri.toString()) > 0) return null
        val title = name.substringBeforeLast('.')
            .replace('_', ' ')
            .replace(Regex("\\s*[\\(\\[].*?[\\)\\]]"), "") // remove "(USA)", "[!]"
            .trim()
        val game = Game(
            title = title.ifBlank { name }, uri = uri.toString(), fileName = name,
            console = console.name, folder = folder
        )
        val id = dao.insert(game)
        return if (id > 0) game.copy(id = id) else null
    }

    private fun summary(added: Int, duplicated: Int, unknown: Int, skipped: Int): String? =
        buildString {
            if (added > 0) append("$added jogo(s) adicionado(s). ")
            if (duplicated > 0) append("$duplicated já estava(m) na biblioteca. ")
            if (unknown > 0) append("$unknown precisa(m) que você escolha o console. ")
            if (skipped > 0) append("$skipped arquivo(s) ignorado(s): nomeie a pasta com o console (ex.: SNES) ou use Importar jogos.")
        }.trim().ifEmpty { null }

    private fun displayName(uri: Uri): String =
        getApplication<Application>().contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            ?: uri.lastPathSegment.orEmpty()

    private fun <T> Flow<List<T>>.state(): StateFlow<List<T>> =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
}
