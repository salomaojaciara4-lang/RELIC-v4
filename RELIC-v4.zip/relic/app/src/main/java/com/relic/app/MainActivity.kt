package com.relic.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.relic.app.data.GameViewModel
import com.relic.app.ui.RelicApp
import com.relic.app.ui.RelicTheme

class MainActivity : ComponentActivity() {
    private val vm: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val neon by vm.neon.collectAsState()
            RelicTheme(neon) { RelicApp(vm) }
        }
    }
}
