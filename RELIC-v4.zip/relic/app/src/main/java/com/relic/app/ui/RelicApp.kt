package com.relic.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.relic.app.EmulatorActivity
import com.relic.app.data.Backup
import com.relic.app.data.ConsoleType
import com.relic.app.data.CoreManager
import com.relic.app.data.Game
import com.relic.app.data.GameViewModel

private enum class Tab(val label: String, val icon: ImageVector) {
    Home("Início", Icons.Default.Home),
    Library("Jogos", Icons.Default.VideogameAsset),
    Consoles("Consoles", Icons.Default.SportsEsports),
    Favorites("Favoritos", Icons.Default.Favorite),
    History("Histórico", Icons.Default.History),
    Settings("Config.", Icons.Default.Settings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RelicApp(vm: GameViewModel) {
    var tab by rememberSaveable { mutableStateOf(Tab.Home) }
    var consoleFilter by rememberSaveable { mutableStateOf<String?>(null) }

    val all by vm.all.collectAsState()
    val recent by vm.recent.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val history by vm.history.collectAsState()
    val query by vm.query.collectAsState()
    val pending by vm.pending.collectAsState()
    val message by vm.message.collectAsState()

    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(message) {
        message?.let { snackbar.showSnackbar(it); vm.message.value = null }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
        if (it.isNotEmpty()) vm.import(it)
    }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) {
        if (it != null) vm.importFolder(it)
    }
    val enriching by vm.enriching.collectAsState()

    var playing by remember { mutableStateOf<Game?>(null) }
    var editing by remember { mutableStateOf<Game?>(null) }

    Scaffold(
        containerColor = Neon.Bg,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            NavigationBar(containerColor = Neon.Surface) {
                Tab.entries.forEach { t ->
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t },
                        icon = { Icon(t.icon, t.label) },
                        label = { Text(t.label, maxLines = 1, style = MaterialTheme.typography.labelSmall) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Neon.Purple,
                            selectedTextColor = Neon.Purple,
                            indicatorColor = Neon.SurfaceHigh,
                            unselectedIconColor = Neon.Muted,
                            unselectedTextColor = Neon.Muted
                        )
                    )
                }
            }
        },
        floatingActionButton = {
            if (tab == Tab.Library || tab == Tab.Home) {
                ExtendedFloatingActionButton(
                    onClick = { picker.launch(arrayOf("*/*")) },
                    containerColor = Neon.Purple,
                    contentColor = androidx.compose.ui.graphics.Color.White,
                    icon = { Icon(Icons.Default.Add, null) },
                    text = { Text("Importar jogos") },
                    modifier = Modifier.neonGlow(16.dp, LocalNeon.current, 28.dp)
                )
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            val onFav: (Game) -> Unit = { vm.toggleFavorite(it) }
            when (tab) {
                Tab.Home -> HomeScreen(
                    recent, favorites, history, all, query, { vm.query.value = it },
                    onFav, { playing = it },
                    onConsole = { consoleFilter = it.name; tab = Tab.Library }
                )
                Tab.Library -> LibraryScreen(
                    games = all, query = query, onQuery = { vm.query.value = it },
                    consoleFilter = consoleFilter, onClearFilter = { consoleFilter = null },
                    onFav = onFav, onPlay = { playing = it }, onEdit = { editing = it },
                    onRemove = { vm.remove(it) },
                    enriching = enriching,
                    onImportFolder = { folderPicker.launch(null) },
                    onFetchCovers = { vm.enrichMissing() }
                )
                Tab.Consoles -> ConsolesScreen(all) { consoleFilter = it.name; tab = Tab.Library }
                Tab.Favorites -> GameList("Favoritos", "Toque no coração de um jogo para favoritá-lo.",
                    favorites, onFav, { playing = it }, { editing = it })
                Tab.History -> GameList("Histórico", "Os jogos que você executar aparecerão aqui.",
                    history, onFav, { playing = it }, { editing = it })
                Tab.Settings -> SettingsScreen(vm, all.size)
            }
        }
    }

    playing?.let { g -> PlayDialog(g, vm) { playing = null } }

    editing?.let { g -> EditDialog(g, { editing = null }) { t, y, ge, d, de ->
        vm.saveInfo(g, t, y, ge, d, de); editing = null
    } }

    pending.firstOrNull()?.let { item ->
        AlertDialog(
            onDismissRequest = { vm.dismissPending(item) },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { vm.dismissPending(item) }) { Text("Ignorar arquivo") } },
            title = { Text("Qual é o console?") },
            text = {
                Column {
                    Text(item.fileName, color = Neon.Muted, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(Modifier.heightIn(max = 320.dp)) {
                        items(ConsoleType.entries.toList()) { c ->
                            Text(
                                "${c.brand} · ${c.label}",
                                Modifier.fillMaxWidth().clickable { vm.assignConsole(item, c) }.padding(vertical = 12.dp)
                            )
                        }
                    }
                }
            },
            containerColor = Neon.SurfaceHigh
        )
    }
}

// ---------- Telas ----------

@Composable
private fun Logo() {
    Column(Modifier.padding(bottom = 4.dp)) {
        Text("RELIC", style = MaterialTheme.typography.headlineMedium, color = Neon.Purple)
        Text("RETRO GAMING EMULATOR", style = MaterialTheme.typography.labelSmall, color = Neon.Muted)
        Text("Seu passado gamer, em uma nova dimensão.", style = MaterialTheme.typography.bodyMedium, color = Neon.Text)
    }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = true,
        placeholder = { Text("Pesquisar jogos") },
        leadingIcon = { Icon(Icons.Default.Search, null) },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Neon.Purple, unfocusedBorderColor = Neon.Violet.copy(alpha = 0.5f)
        )
    )
}

@Composable
private fun HomeScreen(
    recent: List<Game>, favorites: List<Game>, history: List<Game>, all: List<Game>,
    query: String, onQuery: (String) -> Unit,
    onFav: (Game) -> Unit, onPlay: (Game) -> Unit, onConsole: (ConsoleType) -> Unit
) {
    val results = if (query.isBlank()) emptyList() else all.filter { it.matches(query) }
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Logo() }
        item { SearchField(query, onQuery) }
        if (query.isNotBlank()) {
            item { Section("Resultados") }
            if (results.isEmpty()) item { Text("Nenhum jogo encontrado.", color = Neon.Muted) }
            items(results, key = { it.id }) { GameCard(it, onFav, onPlay, {}) }
        } else {
            if (all.isEmpty()) item { EmptyState() }
            shelf("Adicionados recentemente", recent, onPlay)
            shelf("Favoritos", favorites, onPlay)
            shelf("Continue jogando", history, onPlay)
            item { Section("Consoles") }
            item {
                val counts = all.groupingBy { it.console }.eachCount()
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(ConsoleType.entries.filter { counts.containsKey(it.name) }) { c ->
                        AssistChip(
                            onClick = { onConsole(c) },
                            label = { Text("${c.label} (${counts[c.name]})") }
                        )
                    }
                }
            }
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.shelf(
    title: String, games: List<Game>, onPlay: (Game) -> Unit
) {
    if (games.isEmpty()) return
    item { Section(title) }
    item {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(games, key = { it.id }) { CoverTile(it) { onPlay(it) } }
        }
    }
}

@Composable
private fun LibraryScreen(
    games: List<Game>, query: String, onQuery: (String) -> Unit,
    consoleFilter: String?, onClearFilter: () -> Unit,
    onFav: (Game) -> Unit, onPlay: (Game) -> Unit, onEdit: (Game) -> Unit, onRemove: (Game) -> Unit,
    enriching: Pair<Int, Int>?, onImportFolder: () -> Unit, onFetchCovers: () -> Unit
) {
    val shown = games.filter { (consoleFilter == null || it.console == consoleFilter) && it.matches(query) }
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Text("Biblioteca", style = MaterialTheme.typography.titleLarge) }
        item { SearchField(query, onQuery) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onImportFolder) {
                    Icon(Icons.Default.Folder, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
                    Text("Importar pasta")
                }
                OutlinedButton(onClick = onFetchCovers, enabled = enriching == null) {
                    Icon(Icons.Default.Image, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
                    Text("Buscar capas")
                }
            }
        }
        if (enriching != null) item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    "Buscando capas e descrições… ${enriching.first + 1} de ${enriching.second}",
                    color = Neon.Muted, style = MaterialTheme.typography.labelSmall
                )
                LinearProgressIndicator(
                    progress = { (enriching.first + 1f) / enriching.second },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        if (consoleFilter != null) item {
            FilterChip(
                selected = true, onClick = onClearFilter,
                label = { Text(ConsoleType.fromName(consoleFilter)?.label ?: consoleFilter) },
                trailingIcon = { Icon(Icons.Default.Close, "Limpar filtro", Modifier.size(16.dp)) }
            )
        }
        if (games.isEmpty()) item { EmptyState() }
        // Sem filtro de console, agrupa por plataforma; com filtro, é uma lista só.
        shown.groupBy { it.console }.toSortedMap(compareBy { ConsoleType.fromName(it)?.ordinal ?: Int.MAX_VALUE })
            .forEach { (console, list) ->
                if (consoleFilter == null) item(key = "h_$console") {
                    Section(ConsoleType.fromName(console)?.label ?: console)
                }
                items(list, key = { it.id }) { GameCard(it, onFav, onPlay, onEdit, onRemove) }
            }
    }
}

@Composable
private fun ConsolesScreen(all: List<Game>, onPick: (ConsoleType) -> Unit) {
    val counts = all.groupingBy { it.console }.eachCount()
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { Text("Consoles", style = MaterialTheme.typography.titleLarge) }
        ConsoleType.entries.groupBy { it.brand }.forEach { (brand, list) ->
            item { Section(brand) }
            items(list) { c ->
                Row(
                    Modifier.fillMaxWidth().neonGlow(6.dp, LocalNeon.current * 0.5f, 14.dp)
                        .clip(RoundedCornerShape(14.dp)).background(Neon.Surface)
                        .clickable { onPick(c) }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(c.label, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                    Text("${counts[c.name] ?: 0} jogos", color = Neon.Muted)
                }
            }
        }
    }
}

@Composable
private fun GameList(
    title: String, empty: String, games: List<Game>,
    onFav: (Game) -> Unit, onPlay: (Game) -> Unit, onEdit: (Game) -> Unit
) {
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Text(title, style = MaterialTheme.typography.titleLarge) }
        if (games.isEmpty()) item { Text(empty, color = Neon.Muted) }
        items(games, key = { it.id }) { GameCard(it, onFav, onPlay, onEdit) }
    }
}

@Composable
private fun SettingsScreen(vm: GameViewModel, gameCount: Int) {
    val neon by vm.neon.collectAsState()
    val context = LocalContext.current
    val filter by vm.filter.collectAsState()
    val sound by vm.sound.collectAsState()
    val swapAB by vm.swapAB.collectAsState()
    val needsRestart by vm.needsRestart.collectAsState()
    val backupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { if (it != null) vm.backup(it) }
    val restoreLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { if (it != null) vm.restore(it) }
    var sizes by remember { mutableStateOf<Triple<Long, Long, Long>?>(null) }
    var sizeTick by remember { mutableStateOf(0) }
    LaunchedEffect(sizeTick) {
        sizes = withContext(Dispatchers.IO) {
            Triple(
                Backup.size(context, "cores"),
                Backup.size(context, "covers"),
                Backup.size(context, "saves") + Backup.size(context, "states")
            )
        }
    }
    fun mb(bytes: Long) = if (bytes < 1024 * 1024) "${bytes / 1024} KB" else "%.1f MB".format(bytes / 1048576.0)

    if (needsRestart) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Backup restaurado") },
            text = { Text("O RELIC precisa fechar para carregar os dados restaurados. Abra o app de novo em seguida.") },
            confirmButton = {
                TextButton(onClick = { android.os.Process.killProcess(android.os.Process.myPid()) }) { Text("Fechar o app") }
            },
            containerColor = Neon.SurfaceHigh
        )
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text("Configurações", style = MaterialTheme.typography.titleLarge)
        Column {
            Text("Intensidade do neon: ${(neon * 100).toInt()}%", style = MaterialTheme.typography.titleMedium)
            Slider(value = neon, onValueChange = vm::setNeon)
        }
        val online by vm.online.collectAsState()
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Capas e descrições automáticas", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Ao importar, o RELIC procura a capa no servidor de miniaturas do libretro e " +
                            "a descrição na Wikipédia. Só o nome do jogo é enviado, nunca o arquivo. " +
                            "Arcade ainda não tem capa automática.",
                        color = Neon.Muted, style = MaterialTheme.typography.bodyMedium
                    )
                }
                Switch(checked = online, onCheckedChange = vm::setOnline)
            }
        }
        Column {
            Text("Idioma", style = MaterialTheme.typography.titleMedium)
            Text("Português (Brasil)", color = Neon.Muted)
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Vídeo", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("none" to "Sem filtro", "crt" to "CRT", "lcd" to "LCD").forEach { (key, label) ->
                    FilterChip(selected = filter == key, onClick = { vm.setFilter(key) }, label = { Text(label) })
                }
            }
            Text(
                "O filtro vale a partir do próximo jogo que você abrir. " +
                    "A resolução segue a do próprio console, ampliada para a tela.",
                color = Neon.Muted, style = MaterialTheme.typography.bodyMedium
            )
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Áudio e controles", style = MaterialTheme.typography.titleMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Som dos jogos", Modifier.weight(1f))
                Switch(checked = sound, onCheckedChange = vm::setSound)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Trocar botões A e B")
                    Text("Vale para a tela e para gamepads.", color = Neon.Muted, style = MaterialTheme.typography.labelSmall)
                }
                Switch(checked = swapAB, onCheckedChange = vm::setSwapAB)
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Backup", style = MaterialTheme.typography.titleMedium)
            Text(
                "Salva a biblioteca, os saves, os estados salvos e as capas em um arquivo .zip. " +
                    "As ROMs não entram: após reinstalar ou trocar de aparelho, importe os jogos de novo.",
                color = Neon.Muted, style = MaterialTheme.typography.bodyMedium
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { backupLauncher.launch("relic-backup.zip") }) { Text("Criar backup") }
                OutlinedButton(onClick = { restoreLauncher.launch(arrayOf("application/zip", "application/octet-stream")) }) {
                    Text("Restaurar")
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Armazenamento", style = MaterialTheme.typography.titleMedium)
            Text(
                "$gameCount jogo(s) na biblioteca. Os arquivos dos jogos ficam onde você os guardou; " +
                    "o RELIC guarda só o atalho e as informações.",
                color = Neon.Muted, style = MaterialTheme.typography.bodyMedium
            )
            sizes?.let { (cores, covers, saves) ->
                Text("Núcleos baixados: ${mb(cores)}", color = Neon.Muted)
                Text("Capas: ${mb(covers)}", color = Neon.Muted)
                Text("Saves e estados: ${mb(saves)}", color = Neon.Muted)
            }
            OutlinedButton(onClick = {
                java.io.File(context.filesDir, "cores").deleteRecursively()
                sizeTick++
            }) { Text("Apagar núcleos baixados") }
            Text(
                "Os núcleos são baixados de novo quando você iniciar um jogo.",
                color = Neon.Muted, style = MaterialTheme.typography.labelSmall
            )
        }
    }
}

/**
 * Fluxo do botão Iniciar: sem núcleo para o console → avisa; núcleo instalado → abre o jogo;
 * núcleo ausente → pede permissão para baixar do servidor do libretro.
 */
@Composable
private fun PlayDialog(game: Game, vm: GameViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val console = ConsoleType.fromName(game.console)
    val core = console?.core
    val scope = rememberCoroutineScope()
    var installed by remember { mutableStateOf(core != null && CoreManager.isInstalled(context, core)) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    if (core == null) {
        AlertDialog(
            onDismissRequest = onDismiss,
            confirmButton = { TextButton(onClick = onDismiss) { Text("Entendi") } },
            title = { Text(game.title) },
            text = {
                Text(
                    "${console?.label ?: game.console} ainda não tem núcleo integrado. " +
                        "Nesta versão só NES, Game Boy e Game Boy Color rodam."
                )
            },
            containerColor = Neon.SurfaceHigh
        )
        return
    }

    if (installed) {
        LaunchedEffect(Unit) {
            vm.markPlayed(game)
            context.startActivity(EmulatorActivity.intent(context, game))
            onDismiss()
        }
        return
    }

    val coreName = CoreManager.displayNames[core] ?: core
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("Baixar núcleo de emulação") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Para jogar ${console?.label ?: game.console} o RELIC precisa do núcleo $coreName, baixado do " +
                        "servidor oficial do libretro (buildbot.libretro.com). É feito uma vez só."
                )
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy,
                onClick = {
                    busy = true; error = null
                    scope.launch {
                        CoreManager.download(context, core)
                            .onSuccess { installed = true }
                            .onFailure { error = it.message }
                        busy = false
                    }
                }
            ) { Text("Baixar e jogar") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("Cancelar") } },
        containerColor = Neon.SurfaceHigh
    )
}

// ---------- Componentes ----------

@Composable
private fun Section(text: String) =
    Text(text, style = MaterialTheme.typography.titleMedium, color = Neon.Purple)

@Composable
private fun EmptyState() {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(Icons.Default.VideogameAsset, null, Modifier.size(48.dp), tint = Neon.Violet)
        Text("Sua biblioteca está vazia", style = MaterialTheme.typography.titleMedium)
        Text(
            "Toque em Importar jogos e escolha os arquivos que você já possui no aparelho.",
            color = Neon.Muted
        )
    }
}

private fun Game.matches(q: String) =
    q.isBlank() || title.contains(q, true) ||
        (ConsoleType.fromName(console)?.label ?: console).contains(q, true)

/** Decodifica a capa reduzida (alvo ~480 px de altura) para não gastar memória à toa. */
private fun decodeCover(path: String): ImageBitmap? = runCatching {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    var sample = 1
    while (bounds.outHeight / (sample * 2) >= 480) sample *= 2
    BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })?.asImageBitmap()
}.getOrNull()

@Composable
private fun Cover(game: Game, modifier: Modifier) {
    val bitmap by produceState<ImageBitmap?>(null, game.coverUri) {
        value = game.coverUri?.let { path ->
            withContext(Dispatchers.IO) { decodeCover(path) }
        }
    }
    bitmap?.let {
        Image(it, game.title, modifier, contentScale = ContentScale.Crop)
        return
    }
    val c = ConsoleType.fromName(game.console)
    Box(modifier.background(Neon.Gradient), contentAlignment = Alignment.Center) {
        Text(
            (c?.label ?: game.console).take(8).uppercase(),
            color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f),
            fontWeight = FontWeight.Black, maxLines = 1
        )
    }
}

@Composable
private fun CoverTile(game: Game, onClick: () -> Unit) {
    Column(Modifier.width(120.dp).clickable(onClick = onClick)) {
        Cover(
            game, Modifier.size(120.dp, 160.dp)
                .neonGlow(10.dp, LocalNeon.current, 12.dp).clip(RoundedCornerShape(12.dp))
        )
        Spacer(Modifier.height(6.dp))
        Text(game.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun GameCard(
    game: Game, onFav: (Game) -> Unit, onPlay: (Game) -> Unit,
    onEdit: (Game) -> Unit, onRemove: ((Game) -> Unit)? = null
) {
    val console = ConsoleType.fromName(game.console)
    Row(
        Modifier.fillMaxWidth().neonGlow(8.dp, LocalNeon.current, 16.dp)
            .clip(RoundedCornerShape(16.dp)).background(Neon.Surface).padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Cover(game, Modifier.size(96.dp, 128.dp).clip(RoundedCornerShape(10.dp)))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(game.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(console?.let { "${it.brand} · ${it.label}" } ?: game.console, color = Neon.Purple,
                style = MaterialTheme.typography.labelSmall)
            val meta = listOfNotNull(game.year?.toString(), game.genre, game.developer).joinToString(" · ")
            if (meta.isNotEmpty()) Text(meta, color = Neon.Muted, style = MaterialTheme.typography.labelSmall)
            game.folder?.let { Text("Pasta: $it", color = Neon.Muted, style = MaterialTheme.typography.labelSmall) }
            Text(
                game.description ?: "Sem descrição. Toque em editar para adicionar informações.",
                color = Neon.Muted, maxLines = 3, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyMedium
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { onPlay(game) }, contentPadding = PaddingValues(horizontal = 16.dp)) {
                    Icon(Icons.Default.PlayArrow, null); Text("Iniciar")
                }
                IconButton(onClick = { onFav(game) }) {
                    Icon(
                        if (game.favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        "Favoritar", tint = if (game.favorite) Neon.Pink else Neon.Muted
                    )
                }
                IconButton(onClick = { onEdit(game) }) { Icon(Icons.Default.Edit, "Editar", tint = Neon.Muted) }
                if (onRemove != null) IconButton(onClick = { onRemove(game) }) {
                    Icon(Icons.Default.Delete, "Remover da biblioteca", tint = Neon.Muted)
                }
            }
        }
    }
}

@Composable
private fun EditDialog(
    game: Game, onDismiss: () -> Unit,
    onSave: (String, Int?, String, String, String) -> Unit
) {
    var title by remember { mutableStateOf(game.title) }
    var year by remember { mutableStateOf(game.year?.toString().orEmpty()) }
    var genre by remember { mutableStateOf(game.genre.orEmpty()) }
    var dev by remember { mutableStateOf(game.developer.orEmpty()) }
    var desc by remember { mutableStateOf(game.description.orEmpty()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Neon.SurfaceHigh,
        title = { Text("Informações do jogo") },
        confirmButton = {
            TextButton(onClick = { onSave(title, year.toIntOrNull(), genre, dev, desc) }) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Nome") }, singleLine = true)
                OutlinedTextField(year, { year = it.filter(Char::isDigit).take(4) }, label = { Text("Ano") }, singleLine = true)
                OutlinedTextField(genre, { genre = it }, label = { Text("Gênero") }, singleLine = true)
                OutlinedTextField(dev, { dev = it }, label = { Text("Desenvolvedora") }, singleLine = true)
                OutlinedTextField(desc, { desc = it }, label = { Text("Descrição") }, minLines = 3)
            }
        }
    )
}
