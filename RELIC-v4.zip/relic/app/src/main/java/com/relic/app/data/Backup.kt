package com.relic.app.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.io.File
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Backup em um único .zip: biblioteca (banco), saves, estados salvos e capas.
 * Os núcleos não entram (são baixados de novo). As ROMs também não: o RELIC guarda só o
 * atalho para o arquivo, então depois de restaurar em outro aparelho (ou após reinstalar)
 * é preciso importar os jogos de novo para o app voltar a achar os arquivos.
 */
object Backup {
    private const val DB_ENTRY = "relic.db"
    private val folders = listOf("saves", "states", "covers")

    suspend fun export(context: Context, out: Uri): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            AppDatabase.checkpoint(context) // junta o log do banco no arquivo principal
            var count = 0
            val stream = context.contentResolver.openOutputStream(out) ?: throw IOException("Não consegui criar o arquivo.")
            ZipOutputStream(BufferedOutputStream(stream)).use { zip ->
                fun add(file: File, name: String) {
                    zip.putNextEntry(ZipEntry(name))
                    file.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                    count++
                }
                add(context.getDatabasePath("relic.db"), DB_ENTRY)
                for (dir in folders) {
                    val root = File(context.filesDir, dir)
                    root.walkTopDown().filter { it.isFile }.forEach { add(it, "$dir/${it.relativeTo(root).path}") }
                }
            }
            count
        }
    }

    /** Restaura e deixa o banco fechado: o app precisa ser reiniciado em seguida. */
    suspend fun restore(context: Context, input: Uri): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val stream = context.contentResolver.openInputStream(input) ?: throw IOException("Não consegui abrir o arquivo.")
            // Lê tudo para uma pasta temporária antes de tocar nos dados atuais.
            val staging = File(context.cacheDir, "restore").apply { deleteRecursively(); mkdirs() }
            var hasDb = false
            var count = 0
            ZipInputStream(stream).use { zip ->
                var e = zip.nextEntry
                while (e != null) {
                    if (!e.isDirectory && (e.name == DB_ENTRY || folders.any { e.name.startsWith("$it/") })) {
                        val target = File(staging, e.name)
                        // proteção contra caminhos como "../../x" dentro do zip
                        if (!target.canonicalPath.startsWith(staging.canonicalPath + File.separator)) {
                            throw IOException("Backup inválido.")
                        }
                        target.parentFile?.mkdirs()
                        target.outputStream().use { zip.copyTo(it) }
                        if (e.name == DB_ENTRY) hasDb = true
                        count++
                    }
                    e = zip.nextEntry
                }
            }
            if (!hasDb) throw IOException("Este arquivo não parece um backup do RELIC.")

            AppDatabase.close()
            val dbFile = context.getDatabasePath("relic.db")
            File(dbFile.path + "-wal").delete()
            File(dbFile.path + "-shm").delete()
            File(staging, DB_ENTRY).copyTo(dbFile, overwrite = true)
            for (dir in folders) {
                val src = File(staging, dir)
                if (!src.exists()) continue
                val dst = File(context.filesDir, dir).apply { mkdirs() }
                src.walkTopDown().filter { it.isFile }.forEach {
                    val target = File(dst, it.relativeTo(src).path)
                    target.parentFile?.mkdirs()
                    it.copyTo(target, overwrite = true)
                }
            }
            staging.deleteRecursively()
            count
        }
    }

    /** Tamanho em bytes de uma pasta do app. */
    fun size(context: Context, dir: String): Long =
        File(context.filesDir, dir).walkTopDown().filter { it.isFile }.sumOf { it.length() }
}
