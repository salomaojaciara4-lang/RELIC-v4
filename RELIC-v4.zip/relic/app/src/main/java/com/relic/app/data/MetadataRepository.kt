package com.relic.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.Normalizer

/**
 * Busca capas (servidor de miniaturas do libretro) e descrições (Wikipédia).
 * Ambas as fontes são públicas e não exigem chave de API.
 * Falhas de rede lançam [IOException]; "não encontrado" devolve null.
 */
class MetadataRepository(private val context: Context) {

    private val userAgent = "RELIC/0.2 (app Android de biblioteca retrô)"

    /** Pasta do console no servidor de miniaturas. Arcade usa nomes de romset, então fica sem capa automática. */
    private fun thumbFolder(c: ConsoleType): String? = when (c) {
        ConsoleType.NES -> "Nintendo - Nintendo Entertainment System"
        ConsoleType.SNES -> "Nintendo - Super Nintendo Entertainment System"
        ConsoleType.N64 -> "Nintendo - Nintendo 64"
        ConsoleType.GB -> "Nintendo - Game Boy"
        ConsoleType.GBC -> "Nintendo - Game Boy Color"
        ConsoleType.GBA -> "Nintendo - Game Boy Advance"
        ConsoleType.NDS -> "Nintendo - Nintendo DS"
        ConsoleType.SMS -> "Sega - Master System - Mark III"
        ConsoleType.MEGADRIVE -> "Sega - Mega Drive - Genesis"
        ConsoleType.SEGACD -> "Sega - Mega-CD - Sega CD"
        ConsoleType.S32X -> "Sega - 32X"
        ConsoleType.GG -> "Sega - Game Gear"
        ConsoleType.PS1 -> "Sony - PlayStation"
        ConsoleType.PS2 -> "Sony - PlayStation 2"
        ConsoleType.PSP -> "Sony - PlayStation Portable"
        else -> null
    }

    /** Baixa a capa para o armazenamento interno e devolve o caminho, ou null se não existir. */
    suspend fun cover(game: Game, console: ConsoleType): String? = withContext(Dispatchers.IO) {
        val folder = thumbFolder(console) ?: return@withContext null
        val base = game.fileName.substringBeforeLast('.')
        val bare = base.substringBefore(" (").trim()
        val names = buildList {
            add(base)
            listOf("USA", "Europe", "World", "Japan", "Brazil").forEach { add("$bare ($it)") }
        }.map(::sanitize).distinct()

        val out = File(File(context.filesDir, "covers").apply { mkdirs() }, "${game.id}.png")
        for (name in names) {
            val url = "https://thumbnails.libretro.com/${enc(folder)}/Named_Boxarts/${enc(name)}.png"
            if (download(url, out)) return@withContext out.absolutePath
        }
        null
    }

    /** Resumo da Wikipédia (pt, depois en), aceito só se o título bater e a 1ª frase falar de jogo. */
    suspend fun description(game: Game): String? = withContext(Dispatchers.IO) {
        val title = game.title
        val sources = listOf(
            Triple("pt", "jogo eletrônico", "jogo"),
            Triple("en", "video game", "video game")
        )
        for ((lang, hint, keyword) in sources) {
            val searchUrl = "https://$lang.wikipedia.org/w/api.php?action=query&list=search" +
                "&format=json&srlimit=3&srsearch=${enc("$title $hint")}"
            val body = getText(searchUrl) ?: continue
            val hits = JSONObject(body).optJSONObject("query")?.optJSONArray("search") ?: continue
            for (i in 0 until hits.length()) {
                val page = hits.getJSONObject(i).optString("title")
                if (!similar(page, title)) continue
                val summary = getText(
                    "https://$lang.wikipedia.org/api/rest_v1/page/summary/${enc(page.replace(' ', '_'))}"
                ) ?: continue
                val extract = JSONObject(summary).optString("extract")
                if (extract.substringBefore(". ").contains(keyword, ignoreCase = true)) {
                    return@withContext shorten(extract) + "\n\nFonte: Wikipédia ($lang)"
                }
            }
        }
        null
    }

    // ---------- util ----------

    private fun sanitize(name: String) = name.replace(Regex("[&*/:`<>?\\\\|]"), "_")

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    private fun norm(s: String) =
        Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .lowercase()
            .replace(Regex("[^a-z0-9]"), "")

    private fun similar(page: String, title: String): Boolean {
        val p = norm(page.substringBefore(" ("))
        val t = norm(title)
        return p.isNotEmpty() && t.isNotEmpty() && (p == t || p.contains(t) || t.contains(p))
    }

    private fun shorten(text: String, max: Int = 450): String {
        if (text.length <= max) return text
        val cut = text.take(max)
        val end = cut.lastIndexOf(". ")
        return if (end > 120) cut.take(end + 1) else cut.trimEnd() + "…"
    }

    private fun open(url: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8_000
            readTimeout = 15_000
            setRequestProperty("User-Agent", userAgent)
        }

    /** true = baixou; false = não existe (404 etc.); IOException = sem rede. */
    private fun download(url: String, out: File): Boolean {
        val conn = open(url)
        try {
            if (conn.responseCode != 200) return false
            if (conn.contentType?.startsWith("image") != true) return false
            val tmp = File(out.parentFile, out.name + ".tmp")
            conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            return tmp.renameTo(out) || run { out.delete(); tmp.renameTo(out) }
        } finally {
            conn.disconnect()
        }
    }

    private fun getText(url: String): String? {
        val conn = open(url)
        try {
            if (conn.responseCode != 200) return null
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }
}
